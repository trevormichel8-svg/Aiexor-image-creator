export default function Loading() {
  return <div className="p-6">Generating image…</div>
}
