---

## `eslint.config.js`
```js
export default [
  {
    rules: {
      "no-unused-vars": "error",
      "no-console": "warn",
    },
  },
]
