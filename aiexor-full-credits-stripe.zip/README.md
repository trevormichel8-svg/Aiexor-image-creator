# Aiexor Image Creator

## Setup
```bash
npm install
cp .env.example .env
npm run dev
