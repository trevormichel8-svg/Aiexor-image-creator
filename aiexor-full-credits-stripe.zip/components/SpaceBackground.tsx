export default function SpaceBackground() {
  return (
    <div className="space-bg fixed inset-0 -z-10 pointer-events-none" />
  );
}
